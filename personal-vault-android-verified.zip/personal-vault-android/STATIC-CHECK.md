# گزارش بررسی استاتیک

## PASS
- Node.js JavaScript syntax check برای `android/app/src/main/assets/app.js`.
- XML parsing برای `AndroidManifest.xml`.
- وجود settings.gradle، build.gradle، app/build.gradle و assets اصلی.
- مسیر package/activity با namespace و Manifest هم‌خوان است.
- `compileSdk 36`, `targetSdk 36`, `minSdk 26`.
- AGP 9.4.0 + Gradle 9.6.0 + JDK 17 با مستندات رسمی Android تطبیق داده شد.
- WebViewAssetLoader نسخهٔ 1.17.0 اضافه شد.

## اصلاح‌شده
- حذف HTTP server محلی و `usesCleartextTraffic=true`.
- بارگذاری assetها از `https://appassets.androidplatform.net/assets/`.
- مسدودسازی navigation خارجی WebView.
- جلوگیری از mixed content.
- جلوگیری از file:// URL access.
- مدیریت crash شدن WebView renderer.
- اجرای `startActivityForResult` برای ذخیره فایل روی UI thread.
- حذف کلاس `AssetHttpServer.java`.
- اضافه‌شدن `compileOptions` برای Java 17.

## محدودیت باقی‌مانده
- APK باینری در محیط فعلی ساخته نشده چون Android SDK/Gradle نصب نیست.
- ذخیره فایل/Backup در سمت WebView در حال حاضر داده را Base64 می‌کند و برای فایل‌های خیلی بزرگ می‌تواند مصرف RAM را بالا ببرد؛ برای نسخه‌های بعدی، انتقال chunked به Storage Access Framework پیشنهاد می‌شود.
- ZIP backup با Store method ساخته می‌شود و فشرده‌سازی واقعی DEFLATE ندارد.

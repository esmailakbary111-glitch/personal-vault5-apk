package com.personalvault.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int CREATE_FILE = 4101;
    private static final int PICK_FILE = 4102;
    private static final String APP_ORIGIN = "https://appassets.androidplatform.net/";

    private WebView webView;
    private ValueCallback<Uri[]> pendingChooser;
    private byte[] pendingSaveBytes;
    private String pendingSaveMime;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        setContentView(webView);

        WebView.setWebContentsDebuggingEnabled(false);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !isAllowedAppUrl(request.getUrl());
            }

            @Override
            public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                Toast.makeText(MainActivity.this, "Personal Vault engine stopped. Reopening…", Toast.LENGTH_LONG).show();
                recreate();
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams
            ) {
                if (pendingChooser != null) {
                    pendingChooser.onReceiveValue(null);
                }
                pendingChooser = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(resolveAcceptType(fileChooserParams.getAcceptTypes()));
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);

                try {
                    startActivityForResult(intent, PICK_FILE);
                } catch (RuntimeException e) {
                    pendingChooser = null;
                    filePathCallback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "File picker unavailable", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl(APP_ORIGIN + "assets/index.html");
    }

    private static boolean isAllowedAppUrl(Uri uri) {
        if (uri == null) return false;
        return APP_ORIGIN.equalsIgnoreCase(uri.getScheme() + "://" + uri.getHost() + "/")
                && "/assets/".equalsIgnoreCase(normalizePathPrefix(uri.getPath()));
    }

    private static String normalizePathPrefix(String path) {
        if (path == null) return "";
        String normalized = path.startsWith("/") ? path : "/" + path;
        int slash = normalized.indexOf('/', 1);
        return slash < 0 ? normalized : normalized.substring(0, slash + 1);
    }

    private static String resolveAcceptType(String[] acceptTypes) {
        if (acceptTypes == null) return "*/*";
        for (String raw : acceptTypes) {
            if (raw == null) continue;
            String value = raw.trim().toLowerCase(Locale.ROOT);
            if (!value.isEmpty() && !value.equals("*/*")) return value;
        }
        return "*/*";
    }

    @Override
    protected void onDestroy() {
        if (pendingChooser != null) {
            pendingChooser.onReceiveValue(null);
            pendingChooser = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private final class AndroidBridge {
        @JavascriptInterface
        public void saveFile(String filename, String mimeType, String base64) {
            try {
                pendingSaveBytes = Base64.decode(base64, Base64.DEFAULT);
                pendingSaveMime = mimeType == null || mimeType.trim().isEmpty()
                        ? "application/octet-stream"
                        : mimeType.trim();

                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingSaveMime);
                intent.putExtra(Intent.EXTRA_TITLE, filename == null || filename.trim().isEmpty() ? "download" : filename);
                runOnUiThread(() -> {
                    try {
                        startActivityForResult(intent, CREATE_FILE);
                    } catch (RuntimeException e) {
                        pendingSaveBytes = null;
                        pendingSaveMime = null;
                        Toast.makeText(MainActivity.this, "Could not open save dialog", Toast.LENGTH_LONG).show();
                    }
                });
            } catch (IllegalArgumentException e) {
                pendingSaveBytes = null;
                pendingSaveMime = null;
                Toast.makeText(MainActivity.this, "Could not prepare file", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_FILE) {
            ValueCallback<Uri[]> callback = pendingChooser;
            pendingChooser = null;
            if (callback == null) return;

            if (resultCode != RESULT_OK || data == null) {
                callback.onReceiveValue(null);
                return;
            }

            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                Uri[] uris = new Uri[count];
                for (int i = 0; i < count; i++) {
                    uris[i] = data.getClipData().getItemAt(i).getUri();
                }
                callback.onReceiveValue(uris);
                return;
            }

            Uri uri = data.getData();
            callback.onReceiveValue(uri == null ? null : new Uri[]{uri});
            return;
        }

        if (requestCode == CREATE_FILE) {
            try {
                if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveBytes != null) {
                    try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                        if (out == null) throw new IOException("Cannot open destination");
                        out.write(pendingSaveBytes);
                        out.flush();
                    }
                    Toast.makeText(this, "File saved", Toast.LENGTH_SHORT).show();
                }
            } catch (IOException e) {
                Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            } finally {
                pendingSaveBytes = null;
                pendingSaveMime = null;
            }
        }
    }
}

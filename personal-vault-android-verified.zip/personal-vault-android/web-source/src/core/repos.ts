import { getDB } from './db';
import { uuid } from './utils';
import {
  aesDecrypt, aesEncrypt, decryptJSON, encryptJSON,
} from './crypto';
import type { ItemRecord, ItemPayload, ItemType } from './types';

export async function metaGet<T = unknown>(key: string): Promise<T | undefined> {
  const db = await getDB();
  const row = await db.get('meta', key);
  return row?.value as T | undefined;
}

export async function metaSet(key: string, value: unknown): Promise<void> {
  const db = await getDB();
  await db.put('meta', { key, value });
}

export async function metaDelete(key: string): Promise<void> {
  const db = await getDB();
  await db.delete('meta', key);
}

export interface CreateItemInput {
  type: ItemType;
  mimeType: string;
  size: number;
  payload: ItemPayload;
  blobPlain?: ArrayBuffer;
  dek: CryptoKey;
}

export async function createItem(input: CreateItemInput): Promise<ItemRecord> {
  const db = await getDB();
  const id = uuid();
  const now = Date.now();
  const blobId = input.blobPlain ? uuid() : null;

  const { ciphertext: payloadEnc, iv: payloadIv } = await encryptJSON(input.dek, input.payload);

  const record: ItemRecord = {
    id, type: input.type, size: input.size, mimeType: input.mimeType,
    createdAt: now, updatedAt: now, deletedAt: 0,
    blobId, payload: payloadEnc, payloadIv,
  };

  const tx = db.transaction(['items', 'blobs'], 'readwrite');
  try {
    if (blobId && input.blobPlain) {
      const { ciphertext, iv } = await aesEncrypt(input.dek, input.blobPlain);
      await tx.objectStore('blobs').put({ id: blobId, iv, data: ciphertext, createdAt: now });
    }
    await tx.objectStore('items').put(record);
    await tx.done;
    return record;
  } catch (err) {
    try { await tx.done; } catch { /* noop */ }
    throw err;
  }
}

export async function getItem(id: string): Promise<ItemRecord | undefined> {
  const db = await getDB();
  return db.get('items', id);
}

export async function updateItemPayload(
  id: string, patch: Partial<ItemPayload>, dek: CryptoKey,
): Promise<void> {
  const db = await getDB();
  const item = await db.get('items', id);
  if (!item) throw new Error('Item not found');
  const current = await decryptJSON<ItemPayload>(dek, item.payload, item.payloadIv);
  const merged: ItemPayload = { ...current, ...patch };
  const { ciphertext, iv } = await encryptJSON(dek, merged);
  const updated: ItemRecord = { ...item, payload: ciphertext, payloadIv: iv, updatedAt: Date.now() };
  await db.put('items', updated);
}

export async function listItems(opts: {
  type?: ItemType;
  includeDeleted?: boolean;
  onlyDeleted?: boolean;
  dek: CryptoKey;
  sort?: 'newest' | 'oldest' | 'name';
  search?: string;
}): Promise<Array<{ record: ItemRecord; payload: ItemPayload }>> {
  const db = await getDB();
  const all = await db.getAll('items');
  const filtered = all.filter((it) => {
    if (opts.type && it.type !== opts.type) return false;
    if (opts.onlyDeleted && it.deletedAt === 0) return false;
    if (!opts.includeDeleted && !opts.onlyDeleted && it.deletedAt !== 0) return false;
    return true;
  });

  const withPayload = await Promise.all(
    filtered.map(async (r) => {
      try {
        const payload = await decryptJSON<ItemPayload>(opts.dek, r.payload, r.payloadIv);
        return { record: r, payload };
      } catch {
        return { record: r, payload: { displayName: '(unreadable)' } };
      }
    }),
  );

  const sort = opts.sort ?? 'newest';
  withPayload.sort((a, b) => {
    if (sort === 'newest') return b.record.updatedAt - a.record.updatedAt;
    if (sort === 'oldest') return a.record.updatedAt - b.record.updatedAt;
    return a.payload.displayName.localeCompare(b.payload.displayName, undefined, { sensitivity: 'base' });
  });

  if (opts.search && opts.search.trim()) {
    const q = opts.search.trim().toLowerCase();
    return withPayload.filter(({ payload }) => payload.displayName.toLowerCase().includes(q));
  }
  return withPayload;
}

export async function countByType(type: ItemType): Promise<number> {
  const db = await getDB();
  const all = await db.getAll('items');
  return all.filter((r) => r.type === type && r.deletedAt === 0).length;
}

export async function countTrash(): Promise<number> {
  const db = await getDB();
  const all = await db.getAll('items');
  return all.filter((r) => r.deletedAt !== 0).length;
}

export async function softDeleteItem(id: string): Promise<void> {
  const db = await getDB();
  const item = await db.get('items', id);
  if (!item) return;
  await db.put('items', { ...item, deletedAt: Date.now(), updatedAt: Date.now() });
}

export async function restoreItem(id: string): Promise<void> {
  const db = await getDB();
  const item = await db.get('items', id);
  if (!item) return;
  await db.put('items', { ...item, deletedAt: 0, updatedAt: Date.now() });
}

export async function purgeItem(id: string): Promise<void> {
  const db = await getDB();
  const tx = db.transaction(['items', 'blobs'], 'readwrite');
  const item = await tx.objectStore('items').get(id);
  if (item) {
    if (item.blobId) await tx.objectStore('blobs').delete(item.blobId);
    await tx.objectStore('items').delete(id);
  }
  await tx.done;
}

export async function emptyTrash(): Promise<number> {
  const db = await getDB();
  const all = await db.getAll('items');
  const trash = all.filter((i) => i.deletedAt !== 0);
  const tx = db.transaction(['items', 'blobs'], 'readwrite');
  for (const item of trash) {
    if (item.blobId) await tx.objectStore('blobs').delete(item.blobId);
    await tx.objectStore('items').delete(item.id);
  }
  await tx.done;
  return trash.length;
}

export async function readBlobPlain(blobId: string, dek: CryptoKey): Promise<ArrayBuffer> {
  const db = await getDB();
  const blob = await db.get('blobs', blobId);
  if (!blob) throw new Error('Blob not found');
  return aesDecrypt(dek, blob.data, blob.iv);
}

export async function cleanupOrphans(): Promise<number> {
  const db = await getDB();
  const items = await db.getAll('items');
  const referenced = new Set(items.map((i) => i.blobId).filter((b): b is string => !!b));
  const blobs = await db.getAll('blobs');
  const orphans = blobs.filter((b) => !referenced.has(b.id));
  if (!orphans.length) return 0;
  const tx = db.transaction('blobs', 'readwrite');
  for (const b of orphans) await tx.store.delete(b.id);
  await tx.done;
  return orphans.length;
}

export async function wipeAll(): Promise<void> {
  const db = await getDB();
  const tx = db.transaction(['items', 'blobs', 'meta'], 'readwrite');
  await tx.objectStore('items').clear();
  await tx.objectStore('blobs').clear();
  await tx.objectStore('meta').clear();
  await tx.done;
}

import { openDB, type IDBPDatabase, type DBSchema } from 'idb';
import type { ItemRecord, BlobRecord } from './types';

interface VaultSchema extends DBSchema {
  meta: { key: string; value: { key: string; value: unknown } };
  items: {
    key: string;
    value: ItemRecord;
    indexes: {
      'by-type-deleted-created': [string, number, number];
      'by-type-deleted-updated': [string, number, number];
      'by-deleted': number;
    };
  };
  blobs: { key: string; value: BlobRecord; indexes: { 'by-created': number } };
}

const DB_NAME = 'personal-vault';
const DB_VERSION = 1;

let dbPromise: Promise<IDBPDatabase<VaultSchema>> | null = null;

export function getDB(): Promise<IDBPDatabase<VaultSchema>> {
  if (!dbPromise) {
    dbPromise = openDB<VaultSchema>(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('meta')) {
          db.createObjectStore('meta', { keyPath: 'key' });
        }
        if (!db.objectStoreNames.contains('items')) {
          const s = db.createObjectStore('items', { keyPath: 'id' });
          s.createIndex('by-type-deleted-created', ['type', 'deletedAt', 'createdAt']);
          s.createIndex('by-type-deleted-updated', ['type', 'deletedAt', 'updatedAt']);
          s.createIndex('by-deleted', 'deletedAt');
        }
        if (!db.objectStoreNames.contains('blobs')) {
          const s = db.createObjectStore('blobs', { keyPath: 'id' });
          s.createIndex('by-created', 'createdAt');
        }
      },
    });
  }
  return dbPromise;
}

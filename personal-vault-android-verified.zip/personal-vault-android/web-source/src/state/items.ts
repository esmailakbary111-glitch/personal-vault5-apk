import { create } from 'zustand';
import { countByType, countTrash, cleanupOrphans } from '../core/repos';

interface CountsState {
  files: number;
  images: number;
  texts: number;
  trash: number;
  refresh: () => Promise<void>;
}

export const useCounts = create<CountsState>((set) => ({
  files: 0, images: 0, texts: 0, trash: 0,
  refresh: async () => {
    const [files, images, texts, trash] = await Promise.all([
      countByType('file'), countByType('image'), countByType('text'), countTrash(),
    ]);
    set({ files, images, texts, trash });
  },
}));

export async function runStartupCleanup() {
  try { await cleanupOrphans(); } catch (e) { console.warn('[vault] cleanup', e); }
}

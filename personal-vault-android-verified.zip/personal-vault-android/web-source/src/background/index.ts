chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.tabs.create({ url: chrome.runtime.getURL('src/app/index.html') });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) {
    sendResponse({ ok: false, error: 'forbidden' });
    return false;
  }
  if (msg && msg.type === 'open-app') {
    chrome.tabs.create({ url: chrome.runtime.getURL('src/app/index.html') });
    sendResponse({ ok: true });
    return true;
  }
  return false;
});

export {};

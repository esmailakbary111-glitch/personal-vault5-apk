import { useRef, useState } from 'react';
import { useVault } from '../../state/vault';
import { useCounts } from '../../state/items';
import { toast } from '../../state/ui';
import { Button, Field, Input } from '../../ui/primitives';
import { Modal, ConfirmDialog } from '../../ui/Modal';
import { downloadBlob, sanitizeForFilename } from '../../core/utils';
import { APP_VERSION, BACKUP_FORMAT_VERSION } from '../../core/backup';

export function Settings() {
  const { changePassword, exportBackup, importBackup, destroy, error } = useVault();
  const refreshCounts = useCounts((s) => s.refresh);

  const [cpOpen, setCpOpen] = useState(false);
  const [cur, setCur] = useState('');
  const [np, setNp] = useState('');
  const [cp, setCp] = useState('');
  const [cpBusy, setCpBusy] = useState(false);
  const [cpError, setCpError] = useState<string | null>(null);

  const fileInput = useRef<HTMLInputElement>(null);
  const [importOpen, setImportOpen] = useState(false);
  const [importData, setImportData] = useState<Uint8Array | null>(null);
  const [importPw, setImportPw] = useState('');
  const [importBusy, setImportBusy] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [busyExport, setBusyExport] = useState(false);

  const [destroyOpen, setDestroyOpen] = useState(false);
  const [destroyBusy, setDestroyBusy] = useState(false);

  async function handleChangePassword(e: React.FormEvent) {
    e.preventDefault();
    setCpError(null);
    if (np.length < 8) return setCpError('New password must be at least 8 characters.');
    if (np.length > 15) return setCpError('New password must be at most 15 characters.');
    if (np !== cp) return setCpError('New passwords do not match.');
    setCpBusy(true);
    try {
      const ok = await changePassword(cur, np);
      if (!ok) { setCpError('Current password is incorrect.'); return; }
      toast('Password changed successfully', 'success');
      setCpOpen(false);
      setCur(''); setNp(''); setCp('');
    } catch (e) { setCpError((e as Error).message); }
    finally { setCpBusy(false); }
  }

  async function handleExport() {
    setBusyExport(true);
    try {
      const bytes = await exportBackup();
      const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      downloadBlob(bytes as unknown as BlobPart, sanitizeForFilename(`personal-vault-${stamp}.vault.zip`), 'application/zip');
      toast('Backup exported', 'success');
    } catch (e) { toast('Export failed: ' + (e as Error).message, 'error'); }
    finally { setBusyExport(false); }
  }

  async function handleFilePick(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    const buf = new Uint8Array(await f.arrayBuffer());
    setImportData(buf);
    setImportPw('');
    setImportError(null);
    setImportOpen(true);
  }

  async function handleImport() {
    if (!importData) return;
    setImportBusy(true);
    setImportError(null);
    try {
      await importBackup(importData, importPw);
      toast('Backup imported successfully', 'success');
      setImportOpen(false);
      setImportData(null);
      await refreshCounts();
    } catch (e) { setImportError((e as Error).message); }
    finally { setImportBusy(false); }
  }

  async function handleDestroy() {
    setDestroyBusy(true);
    try {
      await destroy();
      toast('Vault destroyed', 'info');
    } catch (e) { toast('Failed: ' + (e as Error).message, 'error'); }
    finally { setDestroyBusy(false); setDestroyOpen(false); }
  }

  return (
    <div className="container" style={{ maxWidth: 720 }}>
      <h2 style={{ marginTop: 0 }}>Settings</h2>

      <section className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginTop: 0 }}>Security</h3>
        <p style={{ color: 'var(--fg-muted)', fontSize: 13, marginTop: 0 }}>
          Change the password that protects your vault.
        </p>
        <Button variant="secondary" onClick={() => { setCpOpen(true); setCpError(null); }}>Change password</Button>
      </section>

      <section className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginTop: 0 }}>Backup</h3>
        <p style={{ color: 'var(--fg-muted)', fontSize: 13, marginTop: 0 }}>
          Export all files, images, texts, and trash state to a single archive.
          Import replaces the current vault entirely.
        </p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <Button variant="secondary" loading={busyExport} onClick={handleExport}>Export backup</Button>
          <Button variant="secondary" onClick={() => fileInput.current?.click()}>Import backup</Button>
          <input ref={fileInput} type="file" accept=".zip,.vault,application/zip,application/octet-stream" style={{ display: 'none' }} onChange={handleFilePick} />
        </div>
      </section>

      <section className="card" style={{ marginBottom: 16 }}>
        <h3 style={{ marginTop: 0 }}>Danger zone</h3>
        <p style={{ color: 'var(--fg-muted)', fontSize: 13, marginTop: 0 }}>
          Permanently destroy all data in this vault. This cannot be undone.
        </p>
        <Button variant="danger" onClick={() => setDestroyOpen(true)}>Destroy vault</Button>
      </section>

      <section className="card">
        <h3 style={{ marginTop: 0 }}>About</h3>
        <dl style={{ display: 'grid', gridTemplateColumns: 'auto 1fr', gap: '4px 16px', margin: 0, fontSize: 13 }}>
          <dt style={{ color: 'var(--fg-muted)' }}>Version</dt><dd style={{ margin: 0 }}>{APP_VERSION}</dd>
          <dt style={{ color: 'var(--fg-muted)' }}>Backup schema</dt><dd style={{ margin: 0 }}>v{BACKUP_FORMAT_VERSION}</dd>
          <dt style={{ color: 'var(--fg-muted)' }}>Storage</dt><dd style={{ margin: 0 }}>IndexedDB (local-only)</dd>
          <dt style={{ color: 'var(--fg-muted)' }}>Encryption</dt><dd style={{ margin: 0 }}>AES-GCM 256 · PBKDF2-SHA-256 (600k)</dd>
        </dl>
      </section>

      <Modal
        open={cpOpen}
        onClose={() => { if (!cpBusy) setCpOpen(false); }}
        title="Change password"
        footer={<>
          <Button variant="ghost" onClick={() => setCpOpen(false)} disabled={cpBusy}>Cancel</Button>
          <Button variant="primary" onClick={handleChangePassword} loading={cpBusy}>Save</Button>
        </>}
      >
        <form onSubmit={handleChangePassword}>
          <Field label="Current password" htmlFor="cur">
            <Input id="cur" type="password" maxLength={15} value={cur} onChange={(e) => setCur(e.target.value)} autoFocus autoComplete="current-password" />
          </Field>
          <Field label="New password" hint="8 to 15 characters." htmlFor="np">
            <Input id="np" type="password" maxLength={15} value={np} onChange={(e) => setNp(e.target.value)} autoComplete="new-password" />
          </Field>
          <Field label="Confirm new password" htmlFor="cp">
            <Input id="cp" type="password" maxLength={15} value={cp} onChange={(e) => setCp(e.target.value)} autoComplete="new-password" />
          </Field>
          {(cpError || error) && <div className="field-error" role="alert">{cpError ?? error}</div>}
        </form>
      </Modal>

      <Modal
        open={importOpen}
        onClose={() => { if (!importBusy) { setImportOpen(false); setImportData(null); } }}
        title="Import backup"
        footer={<>
          <Button variant="ghost" onClick={() => { setImportOpen(false); setImportData(null); }} disabled={importBusy}>Cancel</Button>
          <Button variant="danger" onClick={handleImport} loading={importBusy} disabled={!importPw}>Replace vault</Button>
        </>}
      >
        <p style={{ color: 'var(--fg-muted)', marginTop: 0 }}>
          This will <strong>replace all current data</strong> with the backup contents.
          Enter the password that was used when the backup was created.
        </p>
        <Field label="Backup password" htmlFor="ipw">
          <Input id="ipw" type="password" maxLength={15} value={importPw} onChange={(e) => setImportPw(e.target.value)} autoFocus autoComplete="off" />
        </Field>
        {importError && <div className="field-error" role="alert">{importError}</div>}
      </Modal>

      <ConfirmDialog
        open={destroyOpen}
        title="Destroy vault?"
        message="All files, images, and texts will be permanently erased. This cannot be undone. Make sure you have a backup."
        confirmLabel="Destroy everything"
        danger
        busy={destroyBusy}
        onCancel={() => setDestroyOpen(false)}
        onConfirm={handleDestroy}
      />
    </div>
  );
}

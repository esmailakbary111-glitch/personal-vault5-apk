import { useEffect, useState } from 'react';
import { useVault } from '../../state/vault';
import { useCounts } from '../../state/items';
import { toast } from '../../state/ui';
import { listItems, purgeItem, restoreItem, emptyTrash } from '../../core/repos';
import type { ItemPayload, ItemRecord } from '../../core/types';
import { Button, EmptyState } from '../../ui/primitives';
import { ConfirmDialog } from '../../ui/Modal';
import { IconRestore, IconTrash } from '../../ui/icons';
import { formatBytes, formatDate } from '../../core/utils';

interface Row { record: ItemRecord; payload: ItemPayload; }

export function Trash() {
  const dek = useVault((s) => s.dek)!;
  const refreshCounts = useCounts((s) => s.refresh);
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirmRestore, setConfirmRestore] = useState<Row | null>(null);
  const [confirmPurge, setConfirmPurge] = useState<Row | null>(null);
  const [confirmEmpty, setConfirmEmpty] = useState(false);
  const [busy, setBusy] = useState(false);

  async function refresh() {
    setLoading(true);
    try {
      const all = await listItems({ dek, onlyDeleted: true });
      setRows(all);
    } finally { setLoading(false); }
    refreshCounts();
  }

  useEffect(() => { refresh(); /* eslint-disable-next-line */ }, [dek]);

  async function doRestore(row: Row) {
    setBusy(true);
    try {
      await restoreItem(row.record.id);
      toast('Restored', 'success');
      setConfirmRestore(null);
      await refresh();
    } catch (e) { toast((e as Error).message, 'error'); }
    finally { setBusy(false); }
  }

  async function doPurge(row: Row) {
    setBusy(true);
    try {
      await purgeItem(row.record.id);
      toast('Permanently deleted', 'success');
      setConfirmPurge(null);
      await refresh();
    } catch (e) { toast((e as Error).message, 'error'); }
    finally { setBusy(false); }
  }

  async function doEmpty() {
    setBusy(true);
    try {
      const n = await emptyTrash();
      toast(`Permanently deleted ${n} item${n === 1 ? '' : 's'}`, 'success');
      setConfirmEmpty(false);
      await refresh();
    } catch (e) { toast((e as Error).message, 'error'); }
    finally { setBusy(false); }
  }

  return (
    <div className="container">
      <div className="toolbar">
        <h2 style={{ margin: 0, fontSize: 18 }}>Trash</h2>
        <div className="topbar-spacer" />
        {rows.length > 0 && (
          <Button variant="danger" icon={<IconTrash />} onClick={() => setConfirmEmpty(true)}>
            Empty Trash
          </Button>
        )}
      </div>

      {loading ? (
        <div className="empty"><span className="spinner" /></div>
      ) : rows.length === 0 ? (
        <EmptyState
          icon={<IconTrash width={28} height={28} />}
          title="Trash is empty"
          description="Items you delete will appear here and can be restored."
        />
      ) : (
        <div className="item-list" role="list">
          {rows.map((r) => (
            <div key={r.record.id} className="item-row" role="listitem">
              <div className="item-info">
                <div className="item-name" title={r.payload.displayName}>{r.payload.displayName}</div>
                <div className="item-meta">
                  <span className="tag">{r.record.type}</span>
                  {r.record.type !== 'text' && <span>{formatBytes(r.record.size)}</span>}
                  <span>Deleted {formatDate(r.record.deletedAt)}</span>
                </div>
              </div>
              <div className="item-actions">
                <Button size="sm" variant="ghost" icon={<IconRestore />} onClick={() => setConfirmRestore(r)}>Restore</Button>
                <Button size="sm" variant="ghost" icon={<IconTrash />} onClick={() => setConfirmPurge(r)} aria-label="Delete permanently" />
              </div>
            </div>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={!!confirmRestore}
        title="Restore item?"
        message={confirmRestore ? `"${confirmRestore.payload.displayName}" will return to its original section.` : ''}
        confirmLabel="Restore"
        busy={busy}
        onCancel={() => setConfirmRestore(null)}
        onConfirm={() => confirmRestore && doRestore(confirmRestore)}
      />

      <ConfirmDialog
        open={!!confirmPurge}
        title="Delete permanently?"
        message={confirmPurge ? `"${confirmPurge.payload.displayName}" will be permanently destroyed. This cannot be undone.` : ''}
        confirmLabel="Delete permanently"
        danger
        busy={busy}
        onCancel={() => setConfirmPurge(null)}
        onConfirm={() => confirmPurge && doPurge(confirmPurge)}
      />

      <ConfirmDialog
        open={confirmEmpty}
        title="Empty Trash?"
        message={`All ${rows.length} item${rows.length === 1 ? '' : 's'} in Trash will be permanently destroyed. This cannot be undone.`}
        confirmLabel="Empty Trash"
        danger
        busy={busy}
        onCancel={() => setConfirmEmpty(false)}
        onConfirm={doEmpty}
      />
    </div>
  );
}

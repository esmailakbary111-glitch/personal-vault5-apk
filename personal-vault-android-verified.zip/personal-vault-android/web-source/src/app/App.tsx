import { useEffect } from 'react';
import { useVault } from '../state/vault';
import { useCounts, runStartupCleanup } from '../state/items';
import { Setup } from './screens/Setup';
import { Unlock } from './screens/Unlock';
import { Shell } from './shell/Shell';
import { ToastHost } from '../ui/Toast';

function Splash() {
  return (
    <div className="auth-wrap">
      <span className="spinner" style={{ width: 22, height: 22 }} />
    </div>
  );
}

export default function App() {
  const status = useVault((s) => s.status);
  const init = useVault((s) => s.init);
  const refreshCounts = useCounts((s) => s.refresh);

  useEffect(() => {
    (async () => {
      await runStartupCleanup();
      await init();
      await refreshCounts();
    })();
  }, [init, refreshCounts]);

  return (
    <>
      {status === 'loading' && <Splash />}
      {status === 'uninitialized' && <Setup />}
      {status === 'locked' && <Unlock />}
      {status === 'unlocked' && <Shell />}
      <ToastHost />
    </>
  );
}

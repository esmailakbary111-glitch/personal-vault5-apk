import { useEffect, useState } from 'react';
import { useVault } from '../../state/vault';
import { useCounts } from '../../state/items';
import { toast } from '../../state/ui';
import { Dashboard } from '../screens/Dashboard';
import { ItemsScreen } from '../screens/ItemsScreen';
import { Trash } from '../screens/Trash';
import { Settings } from '../screens/Settings';
import type { ItemType } from '../../core/types';
import {
  IconFolder, IconImage, IconText, IconSettings, IconTrash, IconLock,
} from '../../ui/icons';

type Route =
  | { name: 'dashboard' }
  | { name: 'items'; type: ItemType }
  | { name: 'trash' }
  | { name: 'settings' };

export function Shell() {
  const [route, setRoute] = useState<Route>({ name: 'dashboard' });
  const lock = useVault((s) => s.lock);
  const counts = useCounts();

  useEffect(() => {
    counts.refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [route]);

  useEffect(() => {
    let timer: number | null = null;
    const reset = () => {
      if (timer !== null) window.clearTimeout(timer);
      timer = window.setTimeout(() => {
        lock();
        toast('Vault locked due to inactivity', 'info');
      }, 15 * 60 * 1000);
    };
    const events = ['mousemove', 'keydown', 'click', 'touchstart'] as const;
    events.forEach((e) => window.addEventListener(e, reset, { passive: true }));
    reset();
    return () => {
      if (timer !== null) window.clearTimeout(timer);
      events.forEach((e) => window.removeEventListener(e, reset));
    };
  }, [lock]);

  return (
    <div className="shell">
      <header className="topbar">
        <h1 className="topbar-title">Personal Vault</h1>
        <nav className="nav" aria-label="Main navigation">
          <button className={`nav-btn ${route.name === 'dashboard' ? 'active' : ''}`} onClick={() => setRoute({ name: 'dashboard' })}>
            <IconFolder width={16} height={16} /><span>Home</span>
          </button>
          <button className={`nav-btn ${route.name === 'items' && route.type === 'file' ? 'active' : ''}`} onClick={() => setRoute({ name: 'items', type: 'file' })}>
            <IconFolder width={16} height={16} /><span>Files</span>
          </button>
          <button className={`nav-btn ${route.name === 'items' && route.type === 'image' ? 'active' : ''}`} onClick={() => setRoute({ name: 'items', type: 'image' })}>
            <IconImage width={16} height={16} /><span>Images</span>
          </button>
          <button className={`nav-btn ${route.name === 'items' && route.type === 'text' ? 'active' : ''}`} onClick={() => setRoute({ name: 'items', type: 'text' })}>
            <IconText width={16} height={16} /><span>Texts</span>
          </button>
        </nav>
        <div className="topbar-spacer" />
        <button className={`nav-btn ${route.name === 'trash' ? 'active' : ''}`} onClick={() => setRoute({ name: 'trash' })} aria-label="Trash">
          <IconTrash width={16} height={16} />
          <span>Trash{counts.trash > 0 ? ` (${counts.trash})` : ''}</span>
        </button>
        <button className={`nav-btn ${route.name === 'settings' ? 'active' : ''}`} onClick={() => setRoute({ name: 'settings' })} aria-label="Settings">
          <IconSettings width={16} height={16} /><span>Settings</span>
        </button>
        <button className="nav-btn" onClick={() => lock()} aria-label="Lock vault">
          <IconLock width={16} height={16} /><span>Lock</span>
        </button>
      </header>

      <main className="main">
        {route.name === 'dashboard' && (
          <Dashboard counts={counts} onOpen={(type) => setRoute({ name: 'items', type })} />
        )}
        {route.name === 'items' && <ItemsScreen type={route.type} />}
        {route.name === 'trash' && <Trash />}
        {route.name === 'settings' && <Settings />}
      </main>
    </div>
  );
}

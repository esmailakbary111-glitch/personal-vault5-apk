# ساخت APK فقط با گوشی — Personal Vault

این بسته برای ساخت APK با GitHub Actions آماده شده است.

## روش پیشنهادی برای Repository

اگر کل پروژه را از حالت ZIP خارج و فایل‌های آن را داخل Repository قرار می‌دهید، پوشهٔ `.github/workflows/` باید هم همراه پروژه باشد. سپس: `Actions` → `Build Personal Vault APK` → `Run workflow`.

اگر فقط ZIP را در Repository آپلود می‌کنید، Workflow داخلی ZIP تا وقتی ZIP استخراج نشده است توسط GitHub دیده نمی‌شود. در این حالت از فایل Workflow بیرونی `build-apk-from-zip.yml` استفاده کنید تا ZIP را در runner استخراج و Build کند.

## خروجی

پس از Build موفق، در بخش `Artifacts` فایل `personal-vault-apk` قرار می‌گیرد. داخل آن `app-debug.apk` قرار دارد.

## مشخصات Build

- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0
- JDK: 17
- compileSdk / targetSdk: 36
- AndroidX WebKit: 1.17.0

## وضعیت

سورس از نظر ساختار و JavaScript syntax بررسی شده است. APK باینری در این محیط به‌دلیل نبود Android SDK/Gradle ساخته نشده است.

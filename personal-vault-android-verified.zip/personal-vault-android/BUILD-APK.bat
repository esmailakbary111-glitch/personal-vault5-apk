@echo off
setlocal
cd /d "%~dp0android"
where gradle >nul 2>&1
if errorlevel 1 (
  echo Gradle was not found in PATH.
  echo For phone-only build, upload this project to GitHub and run the Build Personal Vault APK workflow.
  exit /b 1
)
gradle --no-daemon :app:assembleDebug
if errorlevel 1 exit /b 1
echo.
echo APK: %cd%\app\build\outputs\apk\debug\app-debug.apk

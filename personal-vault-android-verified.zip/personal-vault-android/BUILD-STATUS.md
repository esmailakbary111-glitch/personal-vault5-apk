# وضعیت بررسی و آماده‌سازی Build — Personal Vault Android

## بررسی انجام‌شده

- ساختار Gradle پروژه بررسی شد.
- JavaScript اصلی با `node --check` بدون خطای syntax بود.
- مشخصات AGP/Gradle/JDK با مستندات رسمی Android برای AGP 9.4.0 تطبیق داده شد.
- معماری WebView از یک HTTP server محلی به `WebViewAssetLoader` منتقل شد تا محتوای داخلی با HTTPS origin و بدون نیاز به cleartext traffic بارگذاری شود.
- وابستگی رسمی AndroidX WebKit نسخه 1.17.0 اضافه شد.
- navigation خارجی WebView مسدود شد.
- mixed content، file URL access و JavaScript window opening محدود شدند.
- مدیریت renderer crash اضافه شد.
- Workflow ساخت GitHub Actions به پروژهٔ مستقیم `android/` اصلاح شد.

## محدودیت Build در این محیط

در این محیط Android SDK و Gradle نصب نیستند؛ بنابراین APK باینری نهایی در همین محیط اجرا نشده است.

## تنظیمات Build تأییدشده از مستندات رسمی

- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0
- JDK: 17
- SDK Build Tools: 36.0.0
- compileSdk / targetSdk: 36

AGP 9.4.0 طبق مستندات رسمی با Gradle 9.6.0 و JDK 17 سازگار است.

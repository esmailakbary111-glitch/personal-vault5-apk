# Personal Vault — Android

نسخهٔ Android مستقل Personal Vault.

## امکانات اصلی

- AES-GCM 256
- PBKDF2-SHA-256 با 600,000 iteration
- DEK مستقل + Wrapped DEK
- IndexedDB محلی
- فایل، تصویر و متن
- جستجو و مرتب‌سازی
- Trash و Restore
- حذف دائمی
- تغییر رمز عبور
- Auto-Lock قابل تنظیم 5 تا 60 دقیقه
- Backup/Restore به ZIP
- انتخاب فایل و ذخیره فایل از طریق Android Storage Access Framework
- بدون نیاز به اینترنت برای اجرای خود Vault

## ساخت APK

پروژهٔ Android در پوشهٔ `android/` قرار دارد.

مشخصات Build:

- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0
- JDK: 17
- compileSdk: 36
- targetSdk: 36
- minSdk: 26
- AndroidX WebKit: 1.17.0

طبق مستندات رسمی Android، AGP 9.4.0 به Gradle 9.6.0 و JDK 17 نیاز دارد. WebViewAssetLoader نیز برای بارگذاری محتوای محلی داخل WebView توصیه شده است.

## ساخت APK فقط با گوشی

Workflow داخل `.github/workflows/build-apk.yml` است.

در GitHub، پروژه را در Repository قرار دهید و از بخش Actions، Workflow با نام `Build Personal Vault APK` را اجرا کنید. خروجی با نام `personal-vault-apk` منتشر می‌شود و داخل آن `app-debug.apk` قرار دارد.

## نکته امنیتی

این نسخه برای اجرای کاملاً محلی طراحی شده است. WebView محتوای برنامه را از `https://appassets.androidplatform.net/assets/` دریافت می‌کند و navigation به آدرس‌های خارجی مسدود است. داده‌های Vault قبل از ذخیره رمزنگاری می‌شوند.

Backup شامل داده‌های رمزنگاری‌شدهٔ Vault است. برای فایل‌های حجیم، مصرف RAM می‌تواند افزایش پیدا کند.
